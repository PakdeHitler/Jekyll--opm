$(document).ready(function(){
    var toggle = document.getElementById("themeToggle");
    var storedTheme = localStorage.getItem('theme') || (window.matchMedia("(prefes-color-scheme: dark)").matches ? "dark" : "light");

    if (storedTheme == "dark") {
        toggle.checked = true;
        document.querySelector("html").classList.add("dark");
    }
    if (storedTheme) {
        document.documentElement.setAttribute('data-theme', storedTheme);
    }

    toggle.onclick = function() {darkLight(); };

    function darkLight() {
        var currentTheme = document.documentElement.getAttribute("data-theme");
        var targetTheme = currentTheme == "dark" ? "light" : "dark";

        document.documentElement.setAttribute('data-theme', targetTheme);
        localStorage.setItem('theme', targetTheme);
        document.querySelector("html").classList.toggle("dark", targetTheme === "dark");
    }
})